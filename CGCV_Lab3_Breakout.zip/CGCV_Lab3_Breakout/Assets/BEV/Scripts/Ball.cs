﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]

public class Ball : MonoBehaviour
{
    public GameManager gamemanager;
    private Rigidbody _rigidBody;
    [SerializeField] private float speed;

    private void Awake()
    {
        _rigidBody = GetComponent<Rigidbody>();
        _rigidBody.isKinematic = false;
        //_rigidBody.useGravity = false;
    }

    private void OnCollisionEnter(Collision other)
    {
        GameObject objectHit = other.gameObject;
        if(objectHit.tag == "Water")
        {
            gamemanager.CollideWater(other);
        }
        if(objectHit.tag == "Brick")
        {
            gamemanager.CollideBrick(other);
        }
    }

    public void Reset()
    {
        speed = 12;
    }

    private void Start()
    {
        //_rigidBody.AddForce(new Vector3(speed, speed, 0));
        _rigidBody.AddForce(new Vector3(0.001f, -speed, 0), ForceMode.Impulse);
    }
}
