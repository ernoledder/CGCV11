﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using umu7.BlockKuzushi3D.Scripts;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : Singleton<GameManager>
{
    private int _brickCount, _lifeCount, _score, displayScore;
    private bool _isGameOver;
    public Ball ball;

    //shows private variables in the Inspector
    [SerializeField] private Transform bricks;
    [SerializeField] private Toggle[] lives;
    [SerializeField] private RectTransform loseScreen, winScreen;
    [SerializeField] private TextMeshProUGUI score;
    [SerializeField] private float time;
    [SerializeField] private Canvas canvasTop;
    [SerializeField] private Canvas canvasBottom;
    [SerializeField] private Canvas canvas;

    private void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    private void Reset()
    {
        bricks = null;
        lives = null;
        loseScreen = null;
        score = null;
        winScreen = null;
        time = 5;
    }

    public void CollideBrick(Collision other)
    {
        if (_isGameOver) return;
        _brickCount--;
        ball.Reset();
        other.gameObject.SetActive(false);
        displayScore++;
        score.text = "Score: " + displayScore.ToString();
        if (_brickCount > 0) return;
        canvas.gameObject.SetActive(true);
        winScreen.gameObject.SetActive(true);
        
        Invoke(nameof(Restart), time);
        _isGameOver = true;
    }
    
    public void CollideWater(Collision other)
    {
        if (_isGameOver) return;

        _lifeCount--;
        lives[_lifeCount].gameObject.SetActive(false);
        ball.Reset();
        displayScore--;
        score.text = "Score: " + displayScore.ToString();
        if (_lifeCount > 0)
        {
            return;
        }
        else
        {
            canvas.gameObject.SetActive(true);
            loseScreen.gameObject.SetActive(true);
            
            Invoke(nameof(Restart), time);
            _isGameOver = true;
        }
        
        
    }


    void Start()
    {
        loseScreen.gameObject.SetActive(false);
        winScreen.gameObject.SetActive(false);
        canvasTop.gameObject.SetActive(true);
        canvasBottom.gameObject.SetActive(true);
        _brickCount = 32;
        _lifeCount = 5;
        displayScore = 12;
        _isGameOver = false;
        Time.timeScale = 0;

    }

    void Update()
    {
        if (_isGameOver) return;
        if (Input.GetKey("r"))
        {
            Restart();

        }
        if (Input.GetKey("escape"))
        {
            Time.timeScale = 0;
        }
        if (Input.GetKey("return"))
        {
            canvasTop.gameObject.SetActive(false);
            Time.timeScale = 1;
        }
    }

}
